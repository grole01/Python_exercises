__author__ = 'pgaref'

__version__ = '1.3.2'

__title__ = 'http_request_randomizer'
__description__ = 'A package using public proxies to randomise http requests'
__uri__ = 'http://pgaref.com/blog/python-proxy'

__author__ = 'Panagiotis Garefalakis'
__email__ = 'pangaref@gmail.com'

__license__ = 'MIT'
__copyright__ = 'Copyright (c) 2020 ' + __author__
